Core/Src/embedded_cli.o: ../Core/Src/embedded_cli.c \
 ../Core/Inc/embedded_cli.h
../Core/Inc/embedded_cli.h:
